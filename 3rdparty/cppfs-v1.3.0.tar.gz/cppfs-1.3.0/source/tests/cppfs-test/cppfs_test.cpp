
#include <gmock/gmock.h>


class cppfs_test: public testing::Test
{
public:
};


TEST_F(cppfs_test, CheckSomeResults)
{
    // [TODO] Implement test

    EXPECT_EQ((unsigned int) 0, 0);
    // ...
}
