
#include <cppfs/AbstractFileHandleBackend.h>


namespace cppfs
{


AbstractFileHandleBackend::AbstractFileHandleBackend()
{
}

AbstractFileHandleBackend::~AbstractFileHandleBackend()
{
}


} // namespace cppfs
