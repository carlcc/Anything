
#include <cppfs/AbstractFileSystem.h>

#include <cppfs/FileWatcher.h>


namespace cppfs
{


AbstractFileSystem::AbstractFileSystem()
{
}

AbstractFileSystem::~AbstractFileSystem()
{
}


} // namespace cppfs
