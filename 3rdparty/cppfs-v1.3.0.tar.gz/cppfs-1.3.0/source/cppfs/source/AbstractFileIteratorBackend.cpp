
#include <cppfs/AbstractFileIteratorBackend.h>


namespace cppfs
{


AbstractFileIteratorBackend::AbstractFileIteratorBackend()
{
}

AbstractFileIteratorBackend::~AbstractFileIteratorBackend()
{
}


} // namespace cppfs
